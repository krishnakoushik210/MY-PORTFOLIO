public class add {
    public static void main(String[] args) {
        int num1 = 3;
        int num2 = 4;
        int result = num1 + num2;
        System.out.println(result);
    }
}
